package qu.edu.qa.cmps251.guiloader;

import java.io.File;
import java.util.ArrayList;

import qu.edu.qa.cmps251.gui.MainFrame;
import qu.edu.qa.cmps251.gui.utils.Utils;

/**
 * Modifications here are not necessary
 *
 */
public class Runner {

	public static void main(String[] args) {

		MainFrame m = new MainFrame();
		m.setVisible(true);
		 // html file
		File f = new File("playlist.html");
		// test function
		ArrayList<String> titles = Utils.extractTitlesFromFile(f);
		
//		// print titles to see the code works
//		for( String t : titles)
//		{
//			System.out.println(t);
//		}
		
		//Utils.getArtist("");
		// this is a new file where the top 100 tites will be saved
		File f2 = new File("need_file.txt");
		Utils.saveToFile(titles, f2);
		System.out.println("done");
		
		
	}

}
