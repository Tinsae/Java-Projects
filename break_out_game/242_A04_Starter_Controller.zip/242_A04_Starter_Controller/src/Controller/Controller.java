/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Model;
import View.View;
import java.awt.event.MouseWheelEvent;
import java.awt.event.MouseWheelListener;

/**
 *
 * @author fred
 */
public class Controller
{

    Model model;
    View view;

    public Controller(Model m, View v)
    {
        model = m;
        view = v;
        
        view.CenterInitialSetup(model.cd.getLinesToDisplay(), model.cd.getHeaders().size());
        
        view.EastInitialSetup(model.gd.getLines(0, 8), model.gd.getHeaders());
        
        model.cd.setBegin(0);

        
        view.CenterUpdate(model.cd.getLines(model.cd.getBegin(), model.cd.getEnd()), model.cd.getHeaders());
        addListeners();
        
       
    }

    private void addListeners()
    {
        view.getInitialframe().getInitialPanel().getCp().addMouseWheelListener(
                new MouseWheelListener()
        {
            @Override
            public void mouseWheelMoved(MouseWheelEvent e)
            {
                int units = e.getUnitsToScroll();
                model.cd.setBegin(model.cd.getBegin()+units);
                view.CenterUpdate(model.cd.getLines(model.cd.getBegin(), model.cd.getEnd()), model.cd.getHeaders());
            }
        }
        );
    }

}
