package View;

import java.awt.*;
import java.util.ArrayList;
import javax.swing.*;

public class InitialFrame extends JFrame

{

    private InitialPanel ip;

    public InitialFrame()
    {
        super("IST 242 - Table Viewer");
        LayoutSetupMAC();
       //this line below // so basically creating object of Initial Panel by calling its constructor
       //its means Initial Panel's constructor is being called by constructor of Initial frame  right ?
       // so now lets see what will happen in Initial Panels Constructor
        ip = new InitialPanel();
        this.getContentPane().add(ip);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(1200, 900);
        setVisible(true);
    }// here we are initializing the Initial Panel, by calling its constructor

    public InitialPanel getInitialPanel()
    {
        return ip;
    }

    public void setInitialPanel(InitialPanel cp)
    {
        this.ip = cp;
    }

    void LayoutSetupMAC()
    {
        
        try
        {
            UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
        } catch (Exception e)
        {
            e.printStackTrace();
        }
        //------------------------------------------------------           
    }

}
