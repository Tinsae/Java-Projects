package View;

import Model.course;
import Model.genEd;
import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JLabel;

public class View
{

    
    private InitialFrame iframe;

    public View()
    {
        
        iframe = new InitialFrame();
    } 

    public void initialSetup()
    {
        //add or update whatever is needed to the initial setup of the graphics
        iframe.repaint();
    }

    public InitialFrame getInitialframe()
    {
        return iframe;
    }

    public void setInitialframe(InitialFrame iframe)
    {
        this.iframe = iframe;
    }
    
    
    public void CenterInitialSetup(int linesToDisplay,int headerSize) {
       
        System.out.println(headerSize);
        CenterPanel cp = this.getInitialframe().getInitialPanel().getCp();
        
        GridLayout gr = new GridLayout(linesToDisplay + 2, headerSize, 10, 10);
        cp.add(new JLabel("")); 
        cp.add(new JLabel("")); 
        cp.setLayout(gr);
       
        for(int i=1; i<=headerSize;i++) {
           
            JButton b = new JButton("header" + i);
            b.setBackground(Color.CYAN);
            cp.add(b);
          
        }
        
        for(int j=1; j<=linesToDisplay;j++) {
            
            
            for(int k=1; k<=headerSize;k++) {
                cp.add(new JButton("line" + j));
                
            }
        }
        
           
        cp.validate();
        cp.repaint(); 
    }
    
    
    public void EastInitialSetup(ArrayList<ArrayList<String>> genEd, ArrayList<String> header) {
       
        EastPanel ep = this.getInitialframe().getInitialPanel().getEp();
        
        GridLayout gl = new GridLayout(genEd.size() + 2, header.size(), 10, 10);
        ep.setLayout(gl);
        ep.add(new JLabel(""));
        
        for(int i=0; i<header.size();i++) {
            JButton b = new JButton(header.get(i));
            b.setBackground(Color.CYAN);
            ep.add(b);           
        }        
       
        for(int j=0; j<genEd.size();j++) {    
            for(int k=0; k<header.size();k++) {
                ep.add(new JButton(genEd.get(j).get(k)));                
            }
        }
        
        ep.validate();
        ep.repaint();
       
    }
    
   
    public void CenterUpdate(ArrayList<ArrayList<String>> lines, ArrayList<String> headers) {
        CenterPanel cp = this.getInitialframe().getInitialPanel().getCp();
        cp.removeAll();
        cp.revalidate();
        cp.add(new JLabel("Center Panel"));
       
        GridLayout gr = new GridLayout(lines.size() + 2, headers.size(), 10, 10);
        cp.add(new JLabel("")); //empty space
        cp.add(new JLabel("")); //empty space2
        cp.setLayout(gr);
        
        for(int i=0; i<headers.size();i++) {
           
            JButton b = new JButton(headers.get(i));
            b.setBackground(Color.CYAN);
            cp.add(b);            
        }        
        for(int j=0; j<lines.size();j++) {        
            for(int k=0; k<headers.size();k++) {
                cp.add(new JButton(lines.get(j).get(k)));
            }
        }
        cp.validate();
        cp.repaint(); 
    }

}
