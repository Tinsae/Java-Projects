package View;

import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.*;
import javax.swing.JLabel;

public class EastPanel extends JPanel
{

    public EastPanel()
    {
        super();
        setBackground(Color.pink);
        add(new JLabel("East Panel"));
    }
}
