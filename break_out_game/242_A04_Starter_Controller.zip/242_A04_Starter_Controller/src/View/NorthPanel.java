package View;

import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.*;

public class NorthPanel extends JPanel
{

    public NorthPanel()
    {
        super();
        setBackground(Color.black);
        GridLayout gr = new GridLayout(1, 1, 10, 10);
        setLayout(gr);
        add(new JButton("North Panel"));
    }
}
