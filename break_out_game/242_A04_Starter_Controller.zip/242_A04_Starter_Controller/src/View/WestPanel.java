package View;

import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.*;

public class WestPanel extends JPanel
{

    public WestPanel()
    {
        super();
        setBackground(Color.yellow);
        add(new JButton("West Panel"));
    }
}
