package View;

import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.*;
import javax.swing.JLabel;

public class CenterPanel extends JPanel
{

    public CenterPanel()
    {
        super();
        setBackground(Color.ORANGE);
        add(new JLabel("Center Panel"));
        //if we just add this it will cause spacing problem
        //so, no we'll add empty spaces
    }
    //this is what we were seeing 4 columns instead of 3
    //so problem was the number of rows and columns we were setting to initialize the grid.
    //lets count how many rows we need.
    //so we needed lines to be displayed + 1 (for headers row) + 1(for Center Panel title) right ?
    //we know lines to be displayed = 20
    //so total 20 + 1 + 1 = 22
    //but see what we were passing
}
