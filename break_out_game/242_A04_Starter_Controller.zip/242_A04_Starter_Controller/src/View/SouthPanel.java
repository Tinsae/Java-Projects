package View;

import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.*;

public class SouthPanel extends JPanel
{

    public SouthPanel()
    {
        super();
        setBackground(Color.blue);
        GridLayout gr = new GridLayout(1, 1, 10, 10);
        setLayout(gr);
        add(new JButton("South Panel"));
    }
}
