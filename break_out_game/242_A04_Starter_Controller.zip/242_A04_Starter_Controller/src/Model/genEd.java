package Model;

import java.util.ArrayList;

public class genEd implements TableMember {

    private String Code;
    private String Description;

    public genEd() {
    }


    public genEd(String a, String b) {
        Description = a;
        Code = b;
    }

    @Override
    public String getAttribute(int n) {
        if (n < 0 || n >= getAttributes().size())
        {
            throw new ArrayIndexOutOfBoundsException();
        }

        return getAttributes().get(n);
    }

    @Override
    public ArrayList<String> getAttributes() {
        ArrayList<String> attributes = new ArrayList<>();
        attributes.add(this.Code);
        attributes.add(this.Description);
        return attributes;
    }

    @Override
    public String getAttributeName(int n) {
        if (n < 0 || n >= getAttributesNames().size()) {
            throw new ArrayIndexOutOfBoundsException();
        }

        return getAttributesNames().get(n);


    }

    @Override
    public ArrayList<String> getAttributesNames() {
        ArrayList<String> attributeNames = new ArrayList<>();
        attributeNames.add("Code");
        attributeNames.add("Description");
        return attributeNames;
    }

    public String getInfo() {
        return "genEd{" + "description=" + getDescription() + ", code=" + getCode() + "}";
    }

    @Override
    public String toString() {
        return getCode();
    }

    /**
     * @return the Code
     */
    public String getCode() {
        return Code;
    }

    /**
     * @param Code the Code to set
     */
    public void setCode(String Code) {
        this.Code = Code;
    }

    /**
     * @return the Description
     */
    public String getDescription() {
        return Description;
    }

    /**
     * @param Description the Description to set
     */
    public void setDescription(String Description) {
        this.Description = Description;
    }

}
