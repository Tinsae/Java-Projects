package Model;

import java.beans.XMLDecoder;
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.util.ArrayList;

public class courseData implements TableData {

    private ArrayList<course> courses;
    private int[] selected;
    private int begin;
    private int linesToDisplay = 20;
    private int end;
    
    //Now getters and setters
    
    public int getBegin() {
        return this.begin;
    }
    
    public void setBegin(int b) {
        if (b >= 0) {
            this.begin = b;
        } else {
            this.begin = 0;
        }
        //as value of begin changes value of end will also change
        //begin and end are line numbers which will be displayed in the courses panel, as that panel scrolls
        //data will scroll and we need to keep updating begin and end.
        this.setEnd();
    }
    
    //now we have this getLinesToDisplay here, which is actually called in Controller
    //so the one we wrote is not needed
    //we need to change one more thing
    //remember the controller class 
    public int getLinesToDisplay() {
        return this.linesToDisplay;
    }
    
    public void setLinesToDisplay(int l) {
        this.linesToDisplay = l;
    }
    
    public int getEnd() {
        return this.end;
    }
    
    public void setEnd() {
        //so basically it needs to return 20 more than the begin line
        //but we need to check the size of courses array as well, as end cannot be more than size of data.
        if(this.getBegin() + 20 <= this.courses.size()) {
            this.end = this.getBegin() + 20;
        } else {
            this.end = this.courses.size();
            this.begin = this.courses.size() - 20; //lets try?
        }
    }

    public courseData() {
        courses = new ArrayList<>();
        loadTable();

    }//yes, but we already had that

    public void ReadCoursesFromXML() {
        try {
            course cs;
            XMLDecoder decoder;
            decoder = new XMLDecoder(new BufferedInputStream(new FileInputStream("CourseTable.xml")));
            cs = new course();
            while (cs != null) {
                try {
                    cs = (course) decoder.readObject();
                    this.courses.add(cs);

                } catch (ArrayIndexOutOfBoundsException theend) {
                    //System.out.println("end of file");
                    break;
                }
            }
            System.out.println(courses.size());
            decoder.close();
        } catch (Exception xx) {
            xx.printStackTrace();
        }
    }
    
    //Can you tell me what is the data type of retun object from this method
    //I mean if you what this method is going to return
    //ok we'll check
    //do you need those comments, cool
    //also this means we need to change one more thing. can you guess ?
    

    @Override
    public void loadTable() {
        this.ReadCoursesFromXML();
            
        

    }

    @Override
    public ArrayList getTable() {
        return this.courses;
    }

    @Override
    public void setSelectedFields(int[] selected) {
        this.selected = selected;

    }
    //found the problem.
    //we implemented setEnd method 
    //read the lines I am about to point at
    //lets go and correct it

    @Override
    public int[] getSelectedFields() {
        return this.selected;
    }
//rest of the part will depend on format, do you need to submit it today ?
    //where is it ?
    //thats the missing part
    @Override
    public ArrayList<String> getHeaders() {
        if (this.courses.size() < 1) {
            throw new IllegalArgumentException("Course length is 0");
        }
        if (selected.length == 0) {
            return this.courses.get(0).getAttributesNames();
        }
        else {
            ArrayList<String> header = new ArrayList<>();

            course Course = this.courses.get(0);
            for (int j = 0; j < selected.length; j++) {
                //so all the attributes will be headers for a course
                //as you can see we are adding getAttributeName to headers
                //yes, so headers will be string
                header.add(Course.getAttributeName(selected[j]));
            }
            return header;
        }
    }

    @Override
    public ArrayList<String> getLine(int line) {
        ArrayList<String> attributes = new ArrayList<>();
        if (selected == null || selected.length == 0) {
            return this.courses.get(line).getAttributes();

        } else {
            course Course = this.courses.get(line);
            for (int j = 0; j < selected.length; j++) {
                attributes.add(Course.getAttribute(selected[j]));
            }

            return attributes;
        }

    }

    //look at the signature of the method which is used
    //we need to use, method getLines which takes 2 arguments begin and end
    //which matches to this method below
    @Override
    public ArrayList<ArrayList<String>> getLines(int firstLine, int lastLine) {
        ArrayList<ArrayList<String>> lines = new ArrayList<ArrayList<String>>();
        for (int i = firstLine; i <= lastLine; i++) {
            lines.add(getLine(i));
        }
        return lines;
    }
    
    //To implement this we need to know what this method does? 
    //what param it takes ?
    //what it returns ?
    //you need to tell me that 
    //do you have some image which tells us what setBegin is suppose to do?
    //we dont need this as we have setBegin above
}
