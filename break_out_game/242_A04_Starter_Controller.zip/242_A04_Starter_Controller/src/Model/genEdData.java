package Model;

import java.util.ArrayList;

public class genEdData  implements TableData
{

    private ArrayList<genEd> genEds;
    private int [] selected;

    public genEdData()
    {
        genEds = new ArrayList<>();
        loadTable();
    }

    public void CreateGenEds()
    {
        genEd ge1 = new genEd("Writing/Speaking", "GWS");
        genEd ge2 = new genEd("Quantification", "GQ");
        genEd ge3 = new genEd("Arts", "GA");
        genEd ge4 = new genEd("Humanities", "GH");
        genEd ge5 = new genEd("Health and Wellness", "GHW");
        genEd ge6 = new genEd("Natural Sciences", "GN");
        genEd ge7 = new genEd("Social and Behavioral Sciences", "GS");
        genEd ge8 = new genEd("United States Cultures", "US");
        genEd ge9 = new genEd("International Cultures", "IL");
        genEds.add(ge1);
        genEds.add(ge2);
        genEds.add(ge3);
        genEds.add(ge4);
        genEds.add(ge5);
        genEds.add(ge6);
        genEds.add(ge7);
        genEds.add(ge8);
        genEds.add(ge9);
    }


    @Override
    public void loadTable() {
        CreateGenEds();
    }

    @Override
    public ArrayList getTable() {
        return genEds;
    }

    @Override
    public void setSelectedFields(int[] selected) {
        this.selected = selected;
    }

    @Override
    public int[] getSelectedFields() {
        return this.selected;
    }

    @Override
    public ArrayList<String> getHeaders() {
        if (genEds.size() < 1)
        {
            throw new IllegalArgumentException("Course length is 0");
        }

        if (selected.length == 0) {
            return genEds.get(0).getAttributesNames();
        }
        else {
            ArrayList<String> header = new ArrayList<>();

            genEd GenEd = genEds.get(0);
            for (int j = 0; j < selected.length; j++) {
                header.add(GenEd.getAttributeName(selected[j]));
            }
            return header;
        }

    }


    @Override
    public ArrayList<String> getLine(int line) {

        if (selected.length == 0) {
            return genEds.get(line).getAttributes();
        } else {
            ArrayList<String> attributes = new ArrayList<>();

            genEd GenEd = genEds.get(line);
            for (int j = 0; j < selected.length; j++) {
                attributes.add(GenEd.getAttribute(selected[j]));
            }

            return attributes;
        }
    }

    //yes, did you write this method ?
    //ok
    //I have a doubt, you could have simply returned ArrayList<genEd> but instead it says 
    //we can't as that is what you have been told to implement
    //so we'll change our method signature
    @Override
    public ArrayList<ArrayList<String>> getLines(int firstLine, int lastLine) {
        ArrayList<ArrayList<String>> lines = new ArrayList<ArrayList<String>>();

        for (int i = firstLine; i <= lastLine; i++) {
            lines.add(getLine(i));
        }
        return lines;
    }


}
