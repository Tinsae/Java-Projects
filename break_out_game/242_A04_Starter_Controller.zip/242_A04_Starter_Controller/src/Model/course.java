package Model;

import java.util.ArrayList;

//A general rule, class names must have first letter Capital
//so this should be Course
//always follow the naming practise, it makes code readable and easy to understand
//also if I am looking at a class by name I'll know it we use small letters to being with for variables
public class course implements TableMember
{
    private courseName Name;
    private ArrayList<genEd> GenEds;
    private String Description;
    private Integer Credits;
    private String PreReqs;
    private String Comments;

    public course()
    {

    }


    @Override
    public String getAttribute(int n) {
        if (n < 0 || n >= getAttributes().size())
        {
            throw new ArrayIndexOutOfBoundsException();
        }

        return getAttributes().get(n).toString();
    }

    @Override
    public ArrayList<String> getAttributes() {
        ArrayList<String> attributes = new ArrayList<>();
        attributes.add(Name.getCourseNameFormatted());
        attributes.add(GenEds.toString());
        attributes.add(this.getDescription());
        attributes.add(Credits+"");
        attributes.add(this.PreReqs);
        attributes.add(this.Comments);
        return attributes;
    }

    @Override
    public String getAttributeName(int n) {
        if (n < 0 || n >= getAttributesNames().size())
        {
            throw new ArrayIndexOutOfBoundsException();
        }

        return getAttributesNames().get(n);
    }//which 4 ?
    //can you repeat

    @Override
    public ArrayList<String> getAttributesNames() {
        ArrayList<String> attributeNames = new ArrayList<>();
        attributeNames.add("Names");
        attributeNames.add("Gen Eds");
        attributeNames.add("Description");
        attributeNames.add("Credits");
        attributeNames.add("PreReqs");
        attributeNames.add("Comments");
        return attributeNames;
    }

    public course(String a, String b, String c, String d, int e, String f, String g)
    {
        Name = new courseName(a, b, c);
        GenEds = new ArrayList<>();
        Description = d;
        Credits = e;
        PreReqs = f;
        Comments = g;
    }

    public course(String a, String b, String c)
    {
        Name = new courseName(a, b, c);
        GenEds = new ArrayList<>();
        Description = "";
        Credits = 0;
        PreReqs = "";
        Comments = "";
    }

    /**
     * @return the name
     */
    public courseName getName()
    {
        return Name;
    }

    /**
     * @param name the name to set
     */
    public void setName(courseName name)
    {
        this.Name = name;
    }

    /**
     * @return the genEds
     */
    public ArrayList<genEd> getGenEds()
    {
        return GenEds;
    }

    /**
     * @param genEds the genEds to set
     */
    public void setGenEds(ArrayList<genEd> genEds)
    {
        this.GenEds = genEds;
    }

    /**
     * @return the description
     */
    public String getDescription()
    {
        return Description;
    }

    /**
     * @param description the description to set
     */
    public void setDescription(String description)
    {
        this.Description = description;
    }

    /**
     * @return the credits
     */
    public int getCredits()
    {
        return Credits;
    }

    /**
     * @param credits the credits to set
     */
    public void setCredits(int credits)
    {
        this.Credits = credits;
    }

    /**
     * @return the preReqs
     */
    public String getPreReqs()
    {
        return PreReqs;
    }

    /**
     * @param preReqs the preReqs to set
     */
    public void setPreReqs(String preReqs)
    {
        this.PreReqs = preReqs;
    }

    /**
     * @return the comments
     */
    public String getComments()
    {
        return Comments;
    }

    /**
     * @param comments the comments to set
     */
    public void setComments(String comments)
    {
        this.Comments = comments;
    }

}
